function IMDMOEA(Global)
% <algorithm> <A>
% Fast and Elitist Multiobjective Genetic Algorithm: NSGA-II

%--------------------------------------------------------------------------
% Copyright (c) 2016-2017 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB Platform
% for Evolutionary Multi-Objective Optimization [Educational Forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
    global igd;%声明变量为全局变量
    igd=0.1;
    metric1=[];

    T=[];
    Score1=[];
    pName = char(Global.problem);

    global hvd;
    hvd = 0.1;
    metric2 =[];
    

    center=[];
    sample = 10;%策略2中采样10N个个体 3的整数倍 D+M
    acc = 1; %对于第三个策略的预测精度可以尝试添加公式
    %% Generate random population
%     Global.NT=10;
    Population = Global.Initialization();
    [~,FrontNo,CrowdDis] = EnvironmentalSelection(Population,Global.N);
    %% Optimization
    
    
    %% Set time step t
    t=0;             %时间序列
    seq=t+1;         %数据索引
    CenterPoint1=[];  % 历史中心点
    [idx,C]=kmeans(Population.decs,3);%对当前种群进行聚类 3类
                 
    center(seq).item = C;%聚类中心
    center(seq).g=[]; %梯度从0开始
    center(seq).dir=[];%定义移动方向和移动距离
    center(seq).dis=[];

    Pt1=Population;  % 上一环境的种群

%      PF=Global.PF;
%      save("C:\Users\XKY\Desktop\figureData\JY2\XKY\objPF.mat","PF");
    
    while Global.NotTermination(Population)
%           Cc=INDIVIDUAL(sum(Population.decs,1)/Global.N);
%           DF(func2str(Global.problem),Global.NT);    %画出对应PF
%           Draw(Global.PF,'ok','Markeredgecolor',[.9 .0 .0],'Markerfacecolor',[.9 .0 .0],'MarkerSize',2);
%           Draw(Cc.objs,'ok','Markeredgecolor',[.0 .9 .0],'Markerfacecolor',[.0 .9 .0],'MarkerSize',5);
%           Draw(Pt1.objs,'k+','Markeredgecolor',[.6 .0 .0],'Markerfacecolor',[.0 .9 .0],'MarkerSize',3);
        if Global.evaluated>0.9*Global.evaluation
%         if Global.evaluated>Global.evaluation-500
            y=0;
        end
%          PF=Global.PF+0.2*t;
%           PF=Global.PF;
%           a=Population.objs;   
%           save("datadmop2\objPF"+t+".mat","PF");
%           save("datadmop2\obj"+t+".mat","a");
%             PF=Global.PF+0.2*t;
%             a=Population.objs+0.2*t;   
%             save("C:\Users\XKY\Desktop\figureData\JY2\XKY\objPF"+t+".mat","PF");
%             save("C:\Users\XKY\Desktop\figureData\JY2\XKY\obj"+t+".mat","a");
          if Change(Global)  % 检测环境变化   
            

            k=0;
            t=t+1;
            seq=t+1;%计数t+1
   
            Decs=Population.decs;%这是已经执行静态算法收敛的种群了
            Population=INDIVIDUAL(Decs);%对个体进行重评估
            
            [idx,C]=kmeans(Population.decs,3);%对当前种群进行聚类 3类                         
            center(seq).item = C;%聚类中心  
            
            Pt2=Population;
            [Population_cluster,center,P1] = gradient_predict(Pt1,Pt2,Global,center,seq,idx);   %获取三个聚类的移动方向                    %预测算子
            [history_pop,P2] = PS_Sampling(Pt2,sample,seq,center,Population_cluster,Global);                           %PS采样算子
            P3 = PF_Sampling(Pt1,Pt2,history_pop,acc,Global);                        %PF采样算子
            Pachive=[P1,P2,P3];
%             Pachive=[P1];
            
            [Population,FrontNo,CrowdDis] = EnvironmentalSelection([Pachive,Population],Global.N);
            Pt1=Population;         
            if t>=2      %除去第一次环境变化   
                score1=IGD(Population.objs,Global.PF);      %计算IGD
                metric1=[metric1,score1];
                migd=sum(metric1)/length(metric1); %计算MIGD
                igd=migd;  %将MIGD通过全局变量igd传给指标函数MIGD()

                T=[T,t];
                Score1=[Score1,log10(score1)]; %存MIGD
%                 save("C:\Users\XKY\Desktop\migdData\"+pName+"\XKY\IGD"+".mat","Score1");

                score2=HV(Population.objs,Global.PF);      %计算HVD
                metric2=[metric2,score2];
                mhvd=sum(metric2)/length(metric2); %计算MHVD
                hvd=mhvd;
            end            
        else
            Offspring  = Global.Variation(Population,Global.N,@RMMEDA_operator);
            [Population,FrontNo,CrowdDis] = EnvironmentalSelection([Population,Offspring],Global.N);         
        end
    end
end
%% 预测策略
function [Population_cluster,center,P1] = gradient_predict(Pt1,Pt2,Global,center,seq,idx)
    %比较聚类中心距离，建立对应关系，计算梯度等的信息
    A = center(seq-1).item;
    B = center(seq).item;%聚类中心
    D = [];
    min_distance = [];
    distance = pdist2(A,B);
    %贪心寻找最近距离
    for i=1:3     
        D = [];
        [x,y] = find(distance == min(min(distance)));% ?
        min_distance(x) = min(min(distance));%聚类移动距离
        First_x = x(1);
        First_y = y(1);
        temp(First_x,:) = B(First_y,:); %聚类重新排序
        D = Pt2(1,idx == First_y); %聚类个体归属
        Population_cluster(First_x).individual = D;
        distance(First_x,:) = inf;
        distance(:,First_y) = inf;
    end
    center(seq).item = temp;%聚类中心重新排序后的结果
    center(seq).dis = min_distance;
    center(seq).dir = center(seq).item-center(seq-1).item;%计算聚类中心移动向量
    POS = [];
    if seq<=3 %使用传统的中心点预测即可
        for i=1:3
            [FrontNo,MaxFNo] = NDSort(Population_cluster(i).individual.objs,length(Population_cluster(i).individual)); 
            First = find(FrontNo==1); 
            POS_temp = Population_cluster(i).individual(First);
%             POS = [POS;POS_temp.decs+0.5*center(seq).dir(i,:)];
%             POS = [POS;POS_temp.decs+1.5*center(seq).dir(i,:)];
            POS = [POS;POS_temp.decs+center(seq).dir(i,:)];
        end
        if seq == 3 %以方向值为梯度值
            center(seq).g=center(seq).dir;
        end
        P1=INDIVIDUAL(POS);    
    else %使用梯度预测 seq>3
%         center(seq).g = center(seq).dir+(center(seq).dir-center(seq-1).dir);
        center(seq).g = center(seq).dir;
%         center(seq).g = 1/2*center(seq-1).g+1/3*center(seq).dir+1/6*center(seq-1).dir;
        for i=1:3 %检查g(i)
           [FrontNo,MaxFNo] = NDSort(Population_cluster(i).individual.objs,length(Population_cluster(i).individual));
           First = find(FrontNo==1);             
           POS_temp = Population_cluster(i).individual(First);%获取每一个聚类的非支配层
%            POS = [POS;POS_temp.decs+0.5*center(seq).g(i,:)];
%            POS = [POS;POS_temp.decs+1.5*center(seq).g(i,:)];
           POS = [POS;POS_temp.decs+center(seq).g(i,:)];
        end   
        P1=INDIVIDUAL(POS);
    end
end

%% PS加强采样
function [history_pop,P2] = PS_Sampling(Pt2,sample,seq,center,Population_cluster,Global) %根据聚类移动方向扩张撒点
%按比例散布M*N个点 按步长生成0.5~1.5之间的随机值来撒点，每个维度上的步长可以不一致
    Decs = [];%采样结果
    %公差渐变数列的公差
    q_num = 25;
%     q_num1 = 3;
%     q_num = (1+sample-3)*(sample-3)/2;
%     num = ceil((sample-3)/2);
%     q_num = (1+num)*num-1;
    
    if seq <= 3
        temp = center(seq).dir;
    else
        temp = center(seq).g;
    end
    
    %寻找中心聚类
    distance = pdist(center(seq).item);%按照（2,1）（3,1）（3,2）的顺序排列
    search_dis = [distance(1)+distance(2),distance(1)+distance(3),distance(2)+distance(3)];
    [~,so] = min(search_dis);
    
    for i=1:3 
%         改用拥挤度距离最大的几个个体
        [CrowdDis,index] = sort(CrowdingDistance1(Population_cluster(i).individual.decs),'descend');   %决策空间拥挤度距离
        if length(index) < 3 %用固定值
            POS_temp=Population_cluster(i).individual(index);
        else
            POS_temp=Population_cluster(i).individual(index(1:3));%每个聚类采样3个
        end
        Dec = [];
        Dec = POS_temp.decs; %存储聚类引导个体的位置
        len = length(POS_temp);  
       
        for row = 1:len
            Decs_temp = [];
                
            for column = 1:Global.D           
                if temp(i,column) < 0 %进化向量 负向
                    q = (Global.lower(column)-center(seq).item(i,column))/q_num;                                           
                else %正向
                    q = (Global.upper(column)-center(seq).item(i,column))/q_num;
                end
                ran = [];
                ran(1) = Dec(row,column)+q;
                for j = 2:sample-1 %生成检测个体
                    if j<6
                        ran(j) = ran(j-1)+j*q;
                    else
                        ran(j) = ran(j-1)+(10-j)*q;
%                         ran(j) = ran(j-1)+5*q;
                    end
                end
                ran(sample) = Dec(row,column)-temp(i ,column);
%                 ran(sample-1) = Dec(row,column)-0.5*temp(i,column);%正中有负
%                 ran(sample-2) = Dec(row,column)-1*temp(i,column);
%                 ran(sample) = Dec(row,column)-1.5*temp(i,column); 
                
                for j = 1:sample %越界检查
                    if ran(j) < Global.lower(column)
                       ran(j) = Dec(row,column) - (Dec(row,column)-Global.lower(column))*(rand(1));
                    end
                    if ran(j) > Global.upper(column)
                        ran(j) = Dec(row,column) + (Global.upper(column)-Dec(row,column))*(rand(1));
                    end
                end               
                Decs_temp = [Decs_temp,ran']; %一个个体对应的21个引导个体
            end
            Decs = [Decs;Decs_temp];%得到所有采样点
        end        
    end
    P2 = INDIVIDUAL(Decs);   %这里选出非支配个体
    history_pop = P2;
%     [FrontNo,MaxFNo] = NDSort(P2.objs,length(P2)); 
%     First = find(FrontNo==1); 
%     P2 = P2(First);
end


%% PF反向突变
function P3 = PF_Sampling(Pt1,Pt2,history_pop,acc,Global) %PF反向映射，使用高斯扰动撒点（对于PF，使用中心点预测，寻找每一维度的最大值和最小值即可）
 %normrnd(0,0.1,0.2*Global.N,Global.D);%均值，方差，行，列
 % 20%的个体添加较大的振动值
    temp = [];%用于暂存目标值
    dot = [];%PF上的点
    Pt3 = history_pop;
    P3 = [];
    len = length(Pt3);
    disturbance = 10;
    
    [FrontNo,MaxFNo] = NDSort(Pt1.objs,Global.N);
    First = find(FrontNo==1); 
    Population_temp1 = Pt1(First);
    temp = Population_temp1.objs; %Pt1非支配解的目标值
    ct1 = sum(temp,1)/length(temp);
    
    [FrontNo,MaxFNo] = NDSort(Pt2.objs,Global.N);
    First = find(FrontNo==1); 
    Population_temp2 = Pt2(First);
    temp = Population_temp2.objs; %Pt2非支配解的目标值
    ct2 = sum(temp,1)/length(temp); %按列平均值
    
    Dir = ct2-ct1; %PF移动方向
    local = [];%初始化
    for i = 1:Global.M %找到每一维上的端点
        L = temp(:,i);
        l_max = find(L == max(L));
        local(i) = l_max(1); %最大值行号
    end
    if Global.M == 2 %预测流形形状
        dot = [dot;temp(local(1),:)+0.5*acc*Dir];
        dot = [dot;temp(local(2),:)+0.5*acc*Dir];
        dot = [dot;ct2+0.5*acc*Dir];
        dot = [dot;temp(local(1),:)+1.5*acc*Dir];
        dot = [dot;temp(local(2),:)+1.5*acc*Dir];
        dot = [dot;ct2+1.5*acc*Dir];
        line1 = polyfit(dot((1:3),1),dot((1:3),2),2); %对PF进行二次曲线拟合，返回三个系数
        line2 = polyfit(dot((4:6),1),dot((4:6),2),2);
        line3 = polyfit([dot(1,1),dot(4,1)],[dot(1,2),dot(4,2)],1); %两条边界直线
        line4 = polyfit([dot(2,1),dot(5,1)],[dot(2,2),dot(5,2)],1);
        for i=1:len
            x = Pt3(i).obj;
            y1 = [x(1)^2,x(1),1];
            y2 = [x(1),1];
            min_y1=min([y1*line1',y1*line2']);
            min_y2=min([y2*line3',y2*line4']);
            max_y1=max([y1*line1',y1*line2']);
            max_y2=max([y2*line3',y2*line4']);
            if (max_y1 > x(2)) && (min_y1 < x(2)) && (min_y2 < x(2)) && (max_y2 > x(2))
               P3 = [P3,Pt3(i)];
            end
        end
    else %Global.M>2
        [FrontNo,MaxFNo] = NDSort(Pt3.objs,Global.N);
        First = find(FrontNo==1); 
        P3 = Pt3(First);
        disturbance = disturbance/2;
    end
    
    %按列生成方差扰动
    sigma = [];
    for i = 1:Global.D
       sigma(i) = Global.upper(i)-Global.lower(i);
       sigma(i) = sigma(i)/disturbance; %三维的扰动值可以小一点，越小越大
    end
    
    L = length(P3);
    Decs = [];
    if ~isempty(P3)
        if L<20
            for j = 1:3 %对应每个点生成3个扰动点
                Dec = [];
                for i = 1:Global.D    
                    M = normrnd(0,sigma(i),L,1);
                    Dec = [Dec,M];
                end 
                Decs = [Decs;P3.decs+Dec];
            end
            if L<7
                Dec = [];
                for i=1:Global.D
                   M = unifrnd(Global.lower(i),Global.upper(i),Global.N/5-3*L,1); %补足20%的个体
                   Dec = [Dec,M];
                end
                Decs = [Decs;Dec];
            end
            P3 = INDIVIDUAL(Decs);
            [FrontNo,MaxFNo] = NDSort(P3.objs,length(P3)); 
            First = find(FrontNo==1); 
            P3 = P3(First); 
        end
    else
        %随机生成20%的个体
        Dec = [];
        for i=1:Global.D
           M = unifrnd(Global.lower(i),Global.upper(i),Global.N/5,1);
           Dec = [Dec,M];
        end
        P3 = INDIVIDUAL(Dec);
        [FrontNo,MaxFNo] = NDSort(P3.objs,length(P3)); 
        First = find(FrontNo==1); 
        P3 = P3(First);     
    end
     
end
function CrowdDis = CrowdingDistance1(PopObj)
% Calculate the crowding distance of each solution in the same front

    [N,M]    = size(PopObj);
    
    CrowdDis = zeros(1,N);
    Fmax     = max(PopObj,[],1);
    Fmin     = min(PopObj,[],1);
    for i = 1 : M
        [~,rank] = sortrows(PopObj(:,i));
        CrowdDis(rank(1))   = inf;
        CrowdDis(rank(end)) = inf;
        for j = 2 : N-1
            CrowdDis(rank(j)) = CrowdDis(rank(j))+(PopObj(rank(j+1),i)-PopObj(rank(j-1),i))/(Fmax(i)-Fmin(i));
        end
    end
end
function isture = Change(Global)
    isture= rem(Global.Current,Global.tao_n) == 0;
end
