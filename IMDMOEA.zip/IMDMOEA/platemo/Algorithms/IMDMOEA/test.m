 
ran = normrnd(0.5,0.3,[10,1]);
%if g(i) > 0
for it = 1:10
   if ran(it) < 0.5
       ran(it) = 1-ran(it)
   end
  if ran(it) > 1 %Global.upper(i)
      ran(it) = 0.5+0.5*rand(1);%Global.upper(i)-a
  end
end
ran1 = sort(ran,'ascend')
%else
ran2 = sort(ran,'descend')

ran3 = [ran1,ran2]