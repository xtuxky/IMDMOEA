%%%%%%MIGD曲线

T=[];
for i=1:30
    T=[T i];
end
problemName = ["JY1";"JY2";"dMOP2";"FDA1";"F5";"F6"];
algorithmName = ["DNSGA2A";"PPS";"PMS";"DMS";"PBDMO";"HPPCM";"XKY"];
mark = ["o";"+";"*";"square";"diamond";"pentagram";"v"];

% for p = 1:6
    figure();
    pro = "F6";
    for j=1:7
        path = "C:\Users\XKY\Desktop\migdData\"+pro+"\"+algorithmName(j,:)+"\IGD"+".mat";
        load(path);
        plot(T, Score1(1:30),'Marker',mark(j,:));
        hold on
    end
    lgd = legend('DNSGA2A','PPS','PMS','DMS','PBDMO','HPPCM','IMDMOEA','location','north');
    lgd.NumColumns = 4;
    title(pro);
    xlabel('Times instance'); 
    ylabel('log(IGD)');
    set(gca,'YLim',[-3 4]);%Y轴的数据显示范围
    set(gca,'XLim',[0 30]);
    set(gcf,'Units','Inches');
    pos = get(gcf,'Position');
    set(gcf,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
    saveName = "C:\Users\XKY\Desktop\migdFigure\"+pro+".pdf";
    print(gcf,'-vector',saveName,'-dpdf','-r600');
% end
