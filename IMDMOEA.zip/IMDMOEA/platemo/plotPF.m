% figure();
% hold on;
%  colors = [0 0.4470 0.7410;0.8500 0.3250 0.0980;0.9290 0.6940 0.1250;0.4940 0.1840 0.5560;
%      0.4660 0.6740 0.1880;.3010 0.7450 0.9330;0.6350 0.0780 0.1840];
% 
% % load("datadmop2\objPF.mat");
%  for t=1:30   
%     load("C:\Users\XKY\Desktop\figureData\FDA1\XKY\objPF"+t+".mat");
% %     load("datadmop2\objPF"+t+".mat");
%     row = [colors(mod(t,7)+1,:)];
% %     plot(PF(:,1),PF(:,2),'-','Markerfacecolor',[1 0 0],'Markeredgecolor',[1 0 0],'LineWidth',0.1 );
%     plot(PF(:,1),PF(:,2),'-','Color',row,'LineWidth',0.1 );
% %     Draw(PF,'-','Markerfacecolor',[1 0 0],'Markeredgecolor',[1 0 0],'LineWidth',0.1 );
%     load("C:\Users\XKY\Desktop\figureData\FDA1\XKY\obj"+t+".mat");
% %     load("datadmop2\obj"+t+".mat");
% %     rrow = [colors(mod(t+1,7)+1,:)]
%      plot(a(:,1),a(:,2),'.','Markerfacecolor',row,'Markeredgecolor',row,'LineWidth',0.1 );
% %     Draw(a,'.','Markerfacecolor',[1 0 0],'Markeredgecolor',[1 0 0],'LineWidth',0.1);
%     hold on;
%  end
% set(gca,'YLim',[0 7]);
% set(gca,'XLim',[0 7]);


problemName = ["dMOP2";"F9";"JY2";"FDA1"];
algorithmName = ["DNSGA2A";"PPS";"PMS";"DMS";"PBDMO";"HPPCM";"XKY"];
% [char(problemName(1,:)),'\',char(problemName(2,:))]
colors = [0 0.4470 0.7410;0.8500 0.3250 0.0980;0.9290 0.6940 0.1250;0.4940 0.1840 0.5560;
    0.4660 0.6740 0.1880;.3010 0.7450 0.9330;0.6350 0.0780 0.1840];

% for i=3:4
    for j=1:7
    i=2;
         path = problemName(i,:)+"\"+algorithmName(j,:);
%          figure();
        figure('visible','off')
        hold on;
        %load("datadmop2\objPF.mat");
        for t=0:30  
            load("C:\Users\XKY\Desktop\figureData\"+path+"\objPF"+t+".mat");
            %load("datadmop2\objPF"+t+".mat");
            row = [colors(mod(t,7)+1,:)];
            plot(PF(:,1),PF(:,2),'-','Color',[1 0 1],'LineWidth',0.1 );
%             plot(PF(:,1),PF(:,2),'-','Color',row,'LineWidth',0.1 );
            load("C:\Users\XKY\Desktop\figureData\"+path+"\obj"+t+".mat");
            %load("datadmop2\obj"+t+".mat");
            %Draw(a,'.','Markerfacecolor',row,'Markeredgecolor',row,'LineWidth',0.5);
            plot(a(:,1),a(:,2),'.','Markerfacecolor',[0.4660 0.6740 0.1880],'Markeredgecolor',[0.4660 0.6740 0.1880],'LineWidth',0.1 );
%             plot(a(:,1),a(:,2),'.','Markerfacecolor',row,'Markeredgecolor',row,'LineWidth',0.1 );
            hold on;
        end
        title(problemName(i,:));
        xlabel('\itf\rm_1'); ylabel('\itf\rm_2');
        set(gca,'Fontname','Times New Roman');
        if i>2
            set(gca,'YLim',[0 7]);
            set(gca,'XLim',[0 7]);
        else
            set(gca,'YLim',[0 1]);
            set(gca,'XLim',[0 1]);
        end
        set(gcf,'Units','Inches');
        pos = get(gcf,'Position');
        set(gcf,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
        saveName = "C:\Users\XKY\Desktop\figure\"+problemName(i,:)+"-"+algorithmName(j,:)+".pdf";
        print(gcf,'-vector',saveName,'-dpdf','-r600');
    end
% end


