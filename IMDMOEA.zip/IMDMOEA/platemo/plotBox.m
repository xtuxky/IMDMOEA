algorithmName = ["PPS";"DNSGA2A";"PMS";"DMS";"PBDMO";"HPPCM";"IMDMOEA"];
colors = [0.94118 1 0.94118;0.98039 0.98039 0.82353;0.9290 0.6940 0.1250;1 0.94118 0.96078;
      0.4660 0.6740 0.1880;.3010 0.7450 0.9330;0.47843 0.5451 0.5451];
  
figure();
boxplot(unnamed,algorithmName,'Colors',[0,0,0],'MedianStyle','line','Symbol','ok');

boxobj = findobj(gca,'Tag','Box');
for i = 1:7
    patch(get(boxobj(i),'XData'),get(boxobj(i),'YData'),colors(i,:),'EdgeColor',[0 0 0],'FaceAlpha',1,...
        'LineWidth',1.5);
end


hold on
h=boxplot(unnamed,algorithmName,'MedianStyle','line','Color',[0,0,0],'Symbol','ok');

hYLabel=ylabel('Rank');
%设置箱子坐标区的线宽
set(h,'LineWidth',1.5);
set(gca, 'Box', 'on', ...                                         % 边框
         'LineWidth', 1,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1])             % 坐标轴颜色
% 字体和字号
set(gca, 'FontName', 'Times New Roman');
set(gca, 'FontSize', 10,'FontWeight' , 'bold');
% 背景颜色
set(gcf,'Color',[1 1 1]);

set(gcf,'Units','Inches');
pos = get(gcf,'Position');
% set(gcf,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);

h1=plot(6,"_",'Color',"r");
h2=plot(meanName,"pentagram"','Color',"k",'MarkerFaceColor','k');
text(0.80,6.4,'6.15');
text(1.8,4.55,'4.80');
text(2.8,3.45,'3.20');
text(3.8,5.4,'5.65');
text(4.8,4.45,'4.70');
text(5.8,2.4,'2.15');
text(6.8,1.6,'1.35');
lgd = legend([h1,h2],'median','mean');

