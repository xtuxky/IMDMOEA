function varargout = DF1(Operation,Global,input)
% <problem> <A>
% Comparison of Dynamic Multiobjective Evolutionary Algorithms: Empirical Results
% operator --- EAreal

%--------------------------------------------------------------------------
% Copyright (c) 2016-2017 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB Platform
% for Evolutionary Multi-Objective Optimization [Educational Forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
switch Operation
        case 'init'
            Global.M        = 2;
            Global.D        = 10;
            
            Global.lower    = zeros(1,Global.D);
            Global.lower    = - Global.lower; %全置-1
            Global.lower(1) = 0;
            
            Global.upper    = ones(1,Global.D); 
            Global.operator = @EAreal;
            
            PopDec    = rand(input,Global.D);
            varargout = {PopDec};
        case 'value'
            PopDec = input;
            
            
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);
            H = 0.75*sin(pi*t/2)+1.25;
          G = abs(sin(pi*t/2));
              
          g = 1+sum((PopDec(:,2:end)-G).^2,2);
           
          
          PopObj(:,1) =PopDec(:,1);
           a= PopDec(:,1)/g;
           PopObj(:,2) = 1-(PopDec(:,1)).^H; 
         
           
           PopCon = [];

            varargout = {input,PopObj,PopCon};


      case 'PF'
%           input=100;
        PopDec = zeros(1,Global.D);
        t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);
        G = abs(sin(pi*t/2));
        H = 0.75*sin(pi*t/2)+1.25;
        x=(0:1/(input-1):1)'; 
%         PopDec(:,1)=x;
        n=Global.N;
%         PopDec(:,2:n) = G; %%加ps的条件
%        g = 1+sum((PopDec(:,2:end)-G).^2);
       f(:,1)=x;
       f(:,2)=1-f(:,1).^H; 
       
       varargout = {f};
    end
end