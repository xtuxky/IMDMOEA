% figure('Color',[0.8 0.8 0.8]);
[x,y,z] = sphere;
surf(x,y,z,'FaceColor',[0.8 1 0.8],'FaceAlpha',0.5,'EdgeColor',[0.8 0.8 0.8],'EdgeAlpha',0.1);
% alpha(0.01)
axis equal
% 
hold on
r=2;
x2 = x*r;
y2 = y*r;
z2 = z*r;
surf(x2,y2,z2,'FaceColor',[1 1 0.6],'FaceAlpha',0.5,'EdgeColor',[0.8 0.8 0.8],'EdgeAlpha',0.1);
% alpha(0.01)
for i=1:2:5
   h1=surf(X(i:i+1,:),Y(i:i+1,:),Z(i:i+1,:),'FaceColor',[1 1 0.6],'FaceAlpha',1); 
%    alpha(0.6);
end
for i=7:2:11
   h2=surf(X(i:i+1,:),Y(i:i+1,:),Z(i:i+1,:),'FaceColor',[0.8 1 0.8],'FaceAlpha',1); 
%    alpha(0.6);
end
% quiver3(lineQ(4,1),lineQ(4,2),lineQ(4,3),lineQ(1,1)-lineQ(4,1),lineQ(1,2)-lineQ(4,2),lineQ(1,3)-lineQ(4,3),'m',"LineWidth",1,'MaxHeadSize',1);
% quiver3(lineQ(5,1),lineQ(5,2),lineQ(5,3),lineQ(2,1)-lineQ(5,1),lineQ(2,2)-lineQ(5,2),lineQ(2,3)-lineQ(5,3),'m',"LineWidth",1,'MaxHeadSize',1);
% quiver3(lineQ(6,1),lineQ(6,2),lineQ(6,3),lineQ(3,1)-lineQ(6,1),lineQ(3,2)-lineQ(6,2),lineQ(3,3)-lineQ(6,3),'m',"LineWidth",1,'MaxHeadSize',1);
% surf(X,Y,Z);

% text(lineQ(4,1),lineQ(4,2),lineQ(4,3),'1');
% shading flat;
% set(gca, 'color', [0.9 0.9 0.9]);
legend([h1,h2],"cluster_{t}","cluster_{t-1}");
xlim([0,2]);
ylim([0,2]);
zlim([0,2]);
xlabel('x1');
ylabel('x2');
zlabel('x3');
% set(gca,'xtick',[]);
% set(gca,'ytick',[]);
% set(gca,'ztick',[]);
% [X,Y] = meshgrid(1:2,1:2);
% Z = sqrtm(1-X.^2-Y.^2);
% surface(X,Y,Z);
% view(3)